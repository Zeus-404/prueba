import sys
import xbmcgui
import xbmcplugin
import requests
from bs4 import BeautifulSoup
from urllib.parse import parse_qsl

BASE_URL = 'https://www.veronline.tax'

# Función principal que maneja las rutas
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        action = params.get('action')
        if action == 'list_videos':
            list_videos(params['category_url'])
        elif action == 'search':
            search_content()
        elif action == 'play_video':
            play_video(params['video_url'])
    else:
        list_categories()

# Listar categorías (Películas, Series, etc.)
def list_categories():
    categories = [
        {'name': 'Películas', 'url': BASE_URL + '/peliculas'},
        {'name': 'Series', 'url': BASE_URL + '/series'},
        {'name': 'Últimos lanzamientos', 'url': BASE_URL + '/ultimos-lanzamientos'},
        {'name': 'Géneros', 'url': BASE_URL + '/generos'},
        {'name': 'Buscar contenido', 'url': 'search'}
    ]

    for category in categories:
        if category['url'] == 'search':
            url = '{}?action=search'.format(sys.argv[0])
        else:
            url = '{}?action=list_videos&category_url={}'.format(sys.argv[0], category['url'])
        li = xbmcgui.ListItem(label=category['name'])
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Función que realiza scraping de una categoría para listar los videos
def list_videos(category_url):
    response = requests.get(category_url)
    if response.status_code == 200:
        videos = scrape_videos(response.text)
        
        for video in videos:
            url = '{}?action=play_video&video_url={}'.format(sys.argv[0], video['url'])
            li = xbmcgui.ListItem(label=video['title'])
            li.setArt({'thumb': video.get('thumbnail', 'resources/default_thumbnail.png')})
            li.setInfo('video', {'title': video['title'], 'genre': video.get('genre', 'Desconocido')})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li)
        
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        xbmcgui.Dialog().notification('Error', 'No se pudo acceder a la página', xbmcgui.NOTIFICATION_ERROR)

# Función para hacer scraping de los videos
def scrape_videos(html):
    soup = BeautifulSoup(html, 'html.parser')
    videos = []

    for item in soup.select('div.video-item'):
        title = item.select_one('h2.title').text.strip()
        video_url = item.select_one('a')['href']
        thumbnail = item.select_one('img')['src'] if item.select_one('img') else None
        
        if not video_url.startswith('http'):
            video_url = BASE_URL + video_url
        if thumbnail and not thumbnail.startswith('http'):
            thumbnail = BASE_URL + thumbnail

        videos.append({
            'title': title,
            'url': video_url,
            'thumbnail': thumbnail
        })
    
    return videos

# Función para reproducir el video
def play_video(video_url):
    play_item = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=play_item)

# Función de búsqueda
def search_content():
    keyboard = xbmc.Keyboard('', 'Buscar contenido')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_query = keyboard.getText()
        search_url = BASE_URL + '/buscar?q=' + search_query.replace(' ', '+')
        list_videos(search_url)

if __name__ == '__main__':
    router(sys.argv[2][1:])
